#!/usr/bin/env python3
"""Two-pass Hack assembler for the Nand2Tetris Hack platform.

Personalized capstone feature for K=85 (K % 3 == 1):
invalid source instructions are reported with their original line number.
Usage: python assembler.py Box.asm [output.hack]
"""
from pathlib import Path
import re
import sys

PREDEFINED = {
    "SP": 0, "LCL": 1, "ARG": 2, "THIS": 3, "THAT": 4,
    "SCREEN": 16384, "KBD": 24576,
}
PREDEFINED.update({f"R{i}": i for i in range(16)})

DEST = {
    "": "000", "M": "001", "D": "010", "MD": "011",
    "A": "100", "AM": "101", "AD": "110", "AMD": "111",
}
JUMP = {
    "": "000", "JGT": "001", "JEQ": "010", "JGE": "011",
    "JLT": "100", "JNE": "101", "JLE": "110", "JMP": "111",
}
COMP = {
    "0": "0101010", "1": "0111111", "-1": "0111010",
    "D": "0001100", "A": "0110000", "M": "1110000",
    "!D": "0001101", "!A": "0110001", "!M": "1110001",
    "-D": "0001111", "-A": "0110011", "-M": "1110011",
    "D+1": "0011111", "A+1": "0110111", "M+1": "1110111",
    "D-1": "0001110", "A-1": "0110010", "M-1": "1110010",
    "D+A": "0000010", "D+M": "1000010", "D-A": "0010011",
    "D-M": "1010011", "A-D": "0000111", "M-D": "1000111",
    "D&A": "0000000", "D&M": "1000000",
    "D|A": "0010101", "D|M": "1010101",
}

SYMBOL_RE = re.compile(r"^[A-Za-z_.$:][A-Za-z0-9_.$:]*$")

class AssemblyError(Exception):
    pass

def clean_source(path):
    """Return (original_line_number, cleaned_instruction) pairs."""
    instructions = []
    for number, raw in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        line = raw.split("//", 1)[0].strip()
        if line:
            instructions.append((number, re.sub(r"\s+", "", line)))
    return instructions

def first_pass(instructions):
    symbols = dict(PREDEFINED)
    rom = 0
    for line_no, line in instructions:
        if line.startswith("(") and line.endswith(")"):
            label = line[1:-1]
            if not SYMBOL_RE.match(label):
                raise AssemblyError(f"Line {line_no}: invalid label '{line}'")
            if label in symbols:
                # K=85, K % 3 == 1: duplicate labels are rejected clearly.
                raise AssemblyError(f"Line {line_no}: label '{label}' is already defined")
            symbols[label] = rom
        else:
            if line.startswith("(") or line.endswith(")"):
                raise AssemblyError(f"Line {line_no}: malformed label '{line}'")
            rom += 1
    return symbols

def encode_a(value, line_no):
    if value.isdigit():
        address = int(value)
    else:
        if not SYMBOL_RE.match(value):
            raise AssemblyError(f"Line {line_no}: invalid A-instruction symbol '{value}'")
        raise KeyError(value)
    if not 0 <= address <= 32767:
        raise AssemblyError(f"Line {line_no}: A-instruction value must be between 0 and 32767")
    return f"{address:016b}"

def assemble(source_path):
    instructions = clean_source(source_path)
    symbols = first_pass(instructions)
    next_variable = 16
    output = []

    for line_no, line in instructions:
        if line.startswith("("):
            continue
        try:
            if line.startswith("@"):
                symbol = line[1:]
                try:
                    code = encode_a(symbol, line_no)
                except KeyError:
                    if symbol not in symbols:
                        symbols[symbol] = next_variable
                        next_variable += 1
                    code = f"{symbols[symbol]:016b}"
            else:
                if line.count("=") > 1 or line.count(";") > 1:
                    raise AssemblyError(f"Line {line_no}: invalid C-instruction '{line}'")
                if "=" in line:
                    dest, remainder = line.split("=", 1)
                else:
                    dest, remainder = "", line
                if ";" in remainder:
                    comp, jump = remainder.split(";", 1)
                else:
                    comp, jump = remainder, ""
                if dest not in DEST:
                    raise AssemblyError(f"Line {line_no}: invalid destination '{dest}'")
                if comp not in COMP:
                    raise AssemblyError(f"Line {line_no}: invalid computation '{comp}'")
                if jump not in JUMP:
                    raise AssemblyError(f"Line {line_no}: invalid jump '{jump}'")
                code = "111" + COMP[comp] + DEST[dest] + JUMP[jump]
            if len(code) != 16 or set(code) - {"0", "1"}:
                raise AssemblyError(f"Line {line_no}: instruction did not produce 16 bits")
            output.append(code)
        except AssemblyError:
            raise
        except Exception as exc:
            raise AssemblyError(f"Line {line_no}: invalid instruction '{line}': {exc}") from exc
    return output, symbols

def main():
    if len(sys.argv) not in (2, 3):
        print("Usage: python assembler.py input.asm [output.hack]")
        raise SystemExit(2)
    source = Path(sys.argv[1])
    destination = Path(sys.argv[2]) if len(sys.argv) == 3 else source.with_suffix(".hack")
    try:
        machine_code, symbols = assemble(source)
    except (AssemblyError, OSError) as exc:
        print(exc, file=sys.stderr)
        raise SystemExit(1)
    destination.write_text("\n".join(machine_code) + "\n", encoding="utf-8")
    print(f"Assembly successful: {len(machine_code)} instructions -> {destination}")
    print(f"Symbols processed: {len(symbols)}")

if __name__ == "__main__":
    main()
