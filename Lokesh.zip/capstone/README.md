# Capstone Project — Make the Computer Draw a Box

**Student:** Lokesh Kumar  
**Roll number:** 2501010285  
**Personal number K:** 85

## Personalized requirements
- `K = 85`
- `K % 3 = 1`: assembler reports invalid instructions with the original source line number.
- `K % 4 = 1`: rectangle width = `16 × (1 + 1) = 32` pixels.
- Start row = 85; height = 20 rows.
- Screen start address = `SCREEN + 32 × 85 = 16384 + 2720 = 19104`.
- Two 16-bit screen words are written per row.

## Files
- `assembler.py` — two-pass Hack assembler with predefined symbols, labels, variables and line-numbered errors.
- `Box.asm` — draws/clears the personalized rectangle depending on keyboard input.
- `Box.hack` — machine code generated from `Box.asm` by this assembler.
- `../Lokesh_Kumar_Capstone_Report.pdf` — report draft.

## Run
```bash
python assembler.py Box.asm
```
This creates `Box.hack` in the same folder. To choose another output:
```bash
python assembler.py Box.asm output.hack
```

## Emulator verification
1. Open `Box.hack` in the Nand2Tetris CPU Emulator.
2. Load the Hack computer's screen and keyboard interface.
3. Run the program. Press a key: a black rectangle should appear. Release all keys: the rectangle should clear.
4. Capture your own emulator screenshot and add it to the report.
5. Assemble `Add.asm`, `Max.asm`, `Rect.asm`, and `Pong.asm` and compare outputs with the official assembler as required by the assignment.

## Part A — HDL integration
The assignment requires your own lab chips to be connected into `CPU.hdl`, `Memory.hdl`, and `Computer.hdl`, then tested with the supplied `.tst` files. Those lab chip files were not included with the uploaded assignment, so they are not fabricated in this repository. Add your verified HDL files and test screenshots before submission.

## GitHub upload
From the parent directory containing `capstone/`:
```bash
git add capstone
git commit -m "Add personalized Nand2Tetris capstone"
git push
```
If this is a new repository, create it on GitHub first, then follow GitHub's instructions to connect the local repository and push.
