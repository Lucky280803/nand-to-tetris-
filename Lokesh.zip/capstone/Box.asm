// Lokesh Kumar | Roll No. 2501010285 | K = 85
// Box: starts at screen row 85, height 20 rows, width 32 pixels (2 words).
// While a key is pressed, fill the rectangle black; otherwise clear it.

(LOOP)
    @KBD
    D=M
    @BLACK
    D;JGT
    @VALUE
    M=0
    @PREPARE
    0;JMP

(BLACK)
    @VALUE
    M=-1

(PREPARE)
    @19104
    D=A
    @PTR
    M=D
    @20
    D=A
    @ROWS
    M=D

(ROW)
    // Write first 16-pixel word.
    @VALUE
    D=M
    @PTR
    A=M
    M=D

    // Advance pointer and write second 16-pixel word.
    @PTR
    M=M+1
    @VALUE
    D=M
    @PTR
    A=M
    M=D

    // Move to next screen row (two words = 32 pixels).
    @PTR
    M=M+1
    @ROWS
    M=M-1
    D=M
    @ROW
    D;JGT

    @LOOP
    0;JMP
